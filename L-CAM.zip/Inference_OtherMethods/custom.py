import torch

# Load the entire checkpoint archive
checkpoint = torch.load(r"C:\Users\Korisnik\Documents\GitHub\L-CAM\snapshots\VGG16_L_CAM_Img\imagenet_epoch_0_glo_step_1.pth.tar")
print()